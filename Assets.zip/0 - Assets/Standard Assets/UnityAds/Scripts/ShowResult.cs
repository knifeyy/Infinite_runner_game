namespace UnityEngine.Advertisements {
  using System;

  public enum ShowResult {
    Failed,
    Skipped,
    Finished
  }
}
